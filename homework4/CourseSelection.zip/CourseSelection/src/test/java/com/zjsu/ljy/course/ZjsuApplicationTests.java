package com.zjsu.ljy.course;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZjsuApplicationTests {

	@Test
	void contextLoads() {
	}

}
